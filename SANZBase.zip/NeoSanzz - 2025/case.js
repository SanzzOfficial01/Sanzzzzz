/*
Base By: Lezz DcodeR
Optimalization By: Eriza Offc
Recode By: SanzzOffc

Sosmed Creator Base:
- Tiktok Creator: https://tiktok.com/@lezzzcoder
- Github Creator: https://github.com/kyxle21
- YouTube Creator: https://youtube.com/@lezzdcoder

Jangan Lupa Untuk Menyebarkan Cinta [ ♥️ ] Dengan Membiarkan Credit Ini Tetap Ada
*/

require("./settings")
const fs = require('fs')
const util = require('util')
const os = require('os')
const axios = require('axios')
const chalk = require('chalk')
const crypto = require('crypto')
const path = require('path')
const speed = require('performance-now')
const { runtime,formatp } = require('./lib/func')
const { exec } = require("child_process")
module.exports = async (sanz, m, store) => {
try {
const sharp = require('sharp')
const from = m.key.remoteJid
const FileType = require('file-type')
const { 
  WA_DEFAULT_EPHEMERAL,
  getAggregateVotesInPollMessage,
  generateWAMessageFromContent,
  proto, 
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  areJidsSameUser,
  getContentType
  } = require("@whiskeysockets/baileys")
const quoted = m.quoted ? m.quoted : m
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : m.mtype === 'interactiveResponseMessage' ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : '.'
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : ''
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const mime = (quoted.msg || quoted).mimetype || ''
const text = q = args.join(" ")
const isPc = from.endsWith('@s.whatsapp.net')
const isCh = from.endsWith('@newsletter')
const isGroup = from.endsWith('@g.us')
const botNumber = await sanz.decodeJid(sanz.user.id)
const sender = m.key.fromMe ? (sanz.user.id.split(':')[0]+'@s.whatsapp.net' || sanz.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const ownerNumber = JSON.parse(fs.readFileSync("./database/owner.json"))
const isCreator = ownerNumber.includes(senderNumber) || isBot

const groupMetadata = isGroup ? await sanz.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = isGroup ? groupMetadata.subject : ''
const participants = isGroup ? await groupMetadata.participants : ''
const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = isGroup ? groupMetadata.owner : ''
const groupMembers = isGroup ? groupMetadata.participants : ''
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false
const isAdmins = isGroup ? groupAdmins.includes(sender) : false

const contactJsonPath = './database/contact.json';
const contactVcfPath = './database/contacts.vcf';

const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const isPremium = premium.includes(m.sender)

//Fake Quoted
const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qpanel = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {
newsletterAdminInviteMessage: {newsletterJid: `120363333019033320@newsletter`, newsletterName: `Hore`, jpegThumbnail: "", caption: `Powered By ${ownername}`, inviteExpiration: 0 }}}

const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `• ѕαηzzѕуη¢ - 𝟐𝟎𝟐𝟓 •`
}}}

const qdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: '• ѕαηzzѕуη¢ - 𝟐𝟎𝟐𝟓 •',jpegThumbnail: ""}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `• ѕαηzzѕуη¢ - 𝟐𝟎𝟐𝟓 •`,jpegThumbnail: ""}}}

const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `• ѕαηzzѕуη¢ - 𝟐𝟎𝟐𝟓 •`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Bot"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `• ѕαηzzѕуη¢ - 𝟐𝟎𝟐𝟓 •`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `• 𝐍𝐞𝐨𝐒𝐚𝐧𝐳𝐳 - 𝟐𝟎𝟐𝟓 •`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `• ѕαηzzѕуη¢ - 𝟐𝟎𝟐𝟓 •`,jpegThumbnail: ""}}}

sanz.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    let quoted = message.msg ? message.msg : message
    let mime = (message.msg || message).mimetype || ''
    let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
    const stream = await downloadContentFromMessage(quoted, messageType)
    let buffer = Buffer.from([])
    for await(const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk])
    }
    let type = await FileType.fromBuffer(buffer)
    let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
    await fs.writeFileSync(trueFileName, buffer)
    return trueFileName
}

// Random Image
const imageUrls = [
        "https://i.ibb.co/m944LxT/image.jpg",
        "https://i.ibb.co/mHSbM3d/image.jpg",
        "https://files.catbox.moe/g4ae8u.jpg",
        "https://files.catbox.moe/9vp33w.jpg",
        "https://files.catbox.moe/6s1c3e.jpg"
    ];
    const randomIndex = Math.floor(Math.random() * imageUrls.length);
    const randomImageUrl = imageUrls[randomIndex];
// Reply
const replyz = (teks) => {
    return sanz.relayMessage(m.chat, {
        requestPaymentMessage: {
            currencyCodeIso4217: 'IDR',
            amount1000: 1000000,
            requestFrom: m.sender,
            noteMessage: {
                extendedTextMessage: {
                    text: teks,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                        }
                    }
                }
            }
        }
    }, {})
}
async function getFile(url) {
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'arraybuffer'
        });

        const tempPath = path.join(__dirname, 'temp.png'); // Simpan sebagai PNG sementara
        const webpPath = path.join(__dirname, 'temp.webp'); // Simpan hasil WebP
        
        // Simpan file asli (PNG/JPG)
        fs.writeFileSync(tempPath, response.data);

        // Konversi ke WebP menggunakan Sharp
        await sharp(tempPath)
            .toFormat('webp')
            .toFile(webpPath);

        // Hapus file asli setelah dikonversi
        fs.unlinkSync(tempPath);

        return {
            data: webpPath,
            mimetype: 'image/webp'
        };
    } catch (error) {
        console.error('Gagal mengambil file:', error);
        return null;
    }
}
// Tampilan Di Console
const figlet = require('figlet');
if (m.message && m.text.startsWith('.')) {  // Hanya menampilkan pesan yang diawali dengan titik
    

    // Membuat tampilan hesanzr dengan font besar menggunakan figlet
    figlet('SANZZ', (err, data) => {
        if (err) {
            console.log(chalk.white('Error with figlet...'));
            return;
        }
        console.log(
            chalk.white('\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n'+data) + '\n' +  // Hesanzr dengan warna oranye cerah
            chalk.bgRed.white(`⫹ 𝐌𝐄𝐒𝐒𝐀𝐆𝐄 ⫺ `) + chalk.redBright('┃  '+m.text) + '\n' +  // Pesan tebal dan warna cerah
            chalk.bgWhite.black(`⫹ 𝐒𝐄𝐍𝐃𝐄𝐑𝐑 ⫺ `) + chalk.redBright('┃  '+m.sender) + '\n' +  // Pengirim dengan warna cerah
            chalk.bgRed.white(`⫹ 𝐌𝐄𝐒𝐓𝐘𝐏𝐄 ⫺ `) + chalk.redBright('┃  '+m.mtype) + '\n' +  // Jenis pesan dengan merah
            chalk.bgWhite.black(`⫹ 𝐅𝐑𝐎𝐌 𝐈𝐍 ⫺ `) + (m.isGroup ? chalk.redBright('┃  GROUP CHAT') : chalk.redBright('┃  PRIVATE CHAT')) + '\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n'  // Status chat dengan latar belakang
        );
    });
}
const qmsg = (quoted.msg || quoted)
// Gak Usah Di Apa Apain Jika Tidak Mau Error
let ppuser
try {
ppuser = await sanz.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://files.catbox.moe/2lw5hm.jpg'
}

const dbPath = './database/listsc.json';

// Load database
function loadDatabase() {
    if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(dbPath));
}

// Save database
function saveDatabase(data) {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

const limitFile = './database/limitusersc.json';
const linkGc = global.linkgc;
const idGc = global.idGc;
const devnomor = `${global.owner}@s.whatsapp.net`;

function getLimitData() {
    if (!fs.existsSync(limitFile)) return {};
    return JSON.parse(fs.readFileSync(limitFile, 'utf-8') || '{}');
}

// Menyimpan data limit ke file JSON
function saveLimitData(data) {
    fs.writeFileSync(limitFile, JSON.stringify(data, null, 2));
}

// Mengecek apakah bot masih dalam grup
async function checkBotInGroup() {
    let groupList = await sanz.groupFetchAllParticipating();
    return Object.keys(groupList).includes(idGc);
}

// Mengecek dan mengatur limit pengguna
async function checkUserLimit(sender, isCreator) {
    let limitData = getLimitData();

    // Jika pengguna adalah isCreator, langsung unlimited
    if (isCreator) {
        limitData[sender] = { limit: 0, unlimited: true };
        saveLimitData(limitData);
        return true;
    }

    // Cek apakah pengguna ada di grup
    let groupMetadata = await sanz.groupMetadata(idGc);
    let isInGroup = groupMetadata.participants.some(p => p.id === sender);

    if (isInGroup) {
        limitData[sender] = { limit: 0, unlimited: true };
    } else {
        if (!limitData[sender]) limitData[sender] = { limit: 3, unlimited: false };
        if (limitData[sender].limit <= 0) return false;
        limitData[sender].limit -= 1;
    }

    saveLimitData(limitData);
    return true;
}
    
    
switch (command) {
case "menu": {
const teksnya = `isi tampilan menu lo disini`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender] 
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
    {
                                        "name": "cta_url",
                                        "buttonParamsJson": JSON.stringify({
                                            "display_text": "WhatsApp Channel 📟",
                                            "url": "https://whatsapp.com/channel/0029VaibU8cJENy5B66lOJ1o",
                                            "merchant_url": "https://whatsapp.com/channel/0029VaibU8cJENy5B66lOJ1o",
                                        })
                                    }
]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await sanz.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case 'ping':{
                const used = process.memoryUsage()
                const cpus = os.cpus().map(cpu => {
                    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
                    return cpu
                })
                const cpu = cpus.reduce((last, cpu, _, {
                    length
                }) => {
                    last.total += cpu.total
                    last.speed += cpu.speed / length
                    last.times.user += cpu.times.user
                    last.times.nice += cpu.times.nice
                    last.times.sys += cpu.times.sys
                    last.times.idle += cpu.times.idle
                    last.times.irq += cpu.times.irq
                    return last
                }, {
                    speed: 0,
                    total: 0,
                    times: {
                        user: 0,
                        nice: 0,
                        sys: 0,
                        idle: 0,
                        irq: 0
                    }
                })
                let timestamp = speed()
                let latensi = speed() - timestamp
                let neww = performance.now()
                let oldd = performance.now()
                let respon = `
Response Speed ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

» Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
`
m.reply(respon);
}
break
case 'self': {
    if (!isCreator) return
    // Ketika Ada Orang Lain/ Selain Owner Yang Mengetik Command Ini Maka Bot Tidak Akan Merespon Walau Menggunakan Mode Public Dan Ini Akan Mengurangi Spam 
    sanz.public = false
    m.reply(`*Switch To Mode :* \`Self\``)
}
break
case 'public': {
    if (!isCreator) return
    // Ketika Ada Orang Lain/ Selain Owner Yang Mengetik Command Ini Maka Bot Tidak Akan Merespon Walau Menggunakan Mode Public Dan Ini Akan Mengurangi Spam
    sanz.public = true
    m.reply(`*Switch To Mode :* \`Public\``)
}
break
case 'owner': {
        try {
        let vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${global.ownername}\nTEL;type=CELL;type=VOICE;waid=${global.owner}:+${global.owner}\nEND:VCARD`;

        let quotedMessage = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Kontak Owner Kami`,jpegThumbnail: ""}}}
            
        

        await sanz.sendMessage(m.chat, { contacts: { displayName: global.ownername, contacts: [{ vcard }] } }, { quoted: quotedMessage });
    } catch (error) {
        console.error("Error saat mengirim kontak owner:", error);
    }
}
break
case 'tqto':{
let tekss = `
*Selaku Developer, saya ucapkan banyak banyak terimakasih kepada para kontributor yang turut serta dalam pengembangan script ini khususnya pada mereka :*

\`Lezz DcodeR :\` Pemilik Base
\`ChatGPT :\` Error Solving
\`Eriza :\` Optimalization
\`Sanzz :\` My Self

*Tanpa Mereka, Script ini Bukanlah Apa apa*
`
m.reply(tekss)
    }
break
case "addprem": {
    if (!isCreator) return
    // Ketika Ada Orang Lain/ Selain Owner Yang Mengetik Command Ini Maka Bot Tidak Akan Merespon Walau Menggunakan Mode Public Dan Ini Akan Mengurangi Spam
    if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} ${global.owner}`)
   let prrkek = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
    let ceknya = await sanz.onWhatsApp(prrkek) // Mengecek Apkah Nomor ${prrkek} Terdaftar Di WhatsApp 
    if (ceknya.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
    premium.push(prrkek)
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
    m.reply(`Successfully Added ${prrkek} To Database`)
}
break

case "delprem": {
    if (!isCreator) return
    // Ketika Ada Orang Lain/ Selain Owner Yang Mengetik Command Ini Maka Bot Tidak Akan Merespon Walau Menggunakan Mode Public Dan Ini Akan Mengurangi Spam
    if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} ${global.owner}`)
    let ya = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
    let unp = premium.indexOf(ya)
    premium.splice(unp, 1)
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
    m.reply(`Successfully Removed ${ya} From Database`)
}
break

//End Case
default:
if ((budy.match) && ["tes","bot"].includes(budy)) {
m.reply(`
\`Bot Activated ⚡\``)
}

if ((budy.match) && ["Assalamualaikum", "assalamualaikum", "Assalamu'alaikum",].includes(budy)) {
m.reply(`WaalaikumSalam ${pushname}`)
}
if ((budy.match) && ["kontol", "asu", "babi", "yatim", " ngentod", "ngentot", "ajg", "yapit", "anj","anjing",].includes(budy)) {
m.reply(` *مَا شَيْءٌ أَثْقَلُ فِيْ مِيْزَانِ الْمُؤْمِنِ يَوْمَ الْقِيَامَةِ مِنْ خُلُقٍ حَسَنٍ وَإِنَّ اللهَ لَيُبْغِضُ الْفَاحِشَ الْبَذِيْءَ* 

Sesungguhnya tidak ada sesuatu apapun yang paling berat ditimbangan kebaikan seorang mu’min pada hari kiamat seperti akhlaq yang mulia, dan sungguh-sungguh (benar-benar) Allāh benci dengan orang yang lisānnya kotor dan kasar.

jangan toxic lagi ya kak *@.* ☺${pushname}`) 
}
if (budy.startsWith('=>')) {
    if (!isCreator) return

    function Return(sul) {
        sat = JSON.stringify(sul, null, 2)
        bang = util.format(sat)
        if (sat == undefined) {
            bang = util.format(sul)
        }
        return m.reply(bang)
    }
    try {
        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
    } catch (e) {
        m.reply(String(e))
    }
}

if (budy.startsWith('>')) {
    if (!isCreator) return;
    try {
        let evaled = await eval(budy.slice(2));
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
        await m.reply(evaled);
    } catch (err) {
        m.reply(String(err));
    }
}

if (budy.startsWith('$')) {
    if (!isCreator) return
    exec(budy.slice(2), (err, stdout) => {
        if (err) return m.reply(`${err}`)
        if (stdout) return m.reply(stdout)
    })
}

}
} catch (err) {
    console.log(util.format(err))
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})
